cd /Volumes/RamDisk

mkdir iMac51-iMac41
mkdir iMac41-iMac51

hdiutil attach -nobrowse iMacEFIiMac51.dmg
cp '/Volumes/iMac EFI Updater/iMacFirmwareUpdate.pkg/Contents/Archive.pax.gz' .
gunzip Archive.pax.gz
pax -r -f Archive.pax
cp 'Applications/Utilities/iMac EFI Firmware Update.app/Contents/Resources/EFIUpdaterApp2.efi' iMac51-iMac41
cp 'Applications/Utilities/iMac EFI Firmware Update.app/Contents/Resources/LOCKED_IM51_0090_09B.fd' iMac41-iMac51/LOCKED_IM41_0055_08B.fd
rm -R Applications
rm -R Archive.pax
hdiutil detach '/Volumes/iMac EFI Updater/'

hdiutil attach -nobrowse iMacEFIiMac41.dmg
cp '/Volumes/iMacUpdate/iMacFirmwareUpdate.pkg/Contents/Archive.pax.gz' .
gunzip Archive.pax.gz
pax -r -f Archive.pax
cp 'Applications/Utilities/iMac EFI Firmware Update.app/Contents/Resources/EFIUpdaterApp.efi' iMac41-iMac51
cp 'Applications/Utilities/iMac EFI Firmware Update.app/Contents/Resources/LOCKED_IM41_0055_08B.fd' iMac51-iMac41/LOCKED_IM51_0090_09B.fd
rm -R Applications
rm -R Archive.pax
hdiutil detach '/Volumes/iMacUpdate/'

patch iMac51-iMac41/EfiUpdaterApp2.efi iMac51EFIUpdater.patch
patch iMac41-iMac51/EfiUpdaterApp.efi iMac41EFIUpdater.patch
